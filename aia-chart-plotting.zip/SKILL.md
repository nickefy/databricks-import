---
name: aia-chart-plotting
description: Use whenever an answer needs a chart or the user asks to plot, chart, graph, visualise, compare or trend a number. Picks the chart type from the question and the data, labels units and currency, and states the key finding first.
metadata:
  compatible-agents: genie
---

# AIA Chart Plotting

Invoke: `/aia-chart-plotting compare quote-to-bind by channel`

Choose the chart from the question and the grain of the data, not from habit.

## 1. Look before you chart

- Check what one row means (one policy, one agent-month, one campaign), the units, nulls and how many groups there are.
- Never add up rates, ratios, averages, balances or durations. Recompute them from their parts (for example conversions / contacts).
- If the measure, period or comparison is unclear, ask one short question first.

## 2. Pick the chart

| Question shape                    | Chart              | Rules                                                                                                            |
| --------------------------------- | ------------------ | ---------------------------------------------------------------------------------------------------------------- |
| Compare categories                | Bar                | Sort largest first. Up to 12 bars; above that show the top 10 plus "Other". Horizontal bars when labels are long |
| Trend over time                   | Line               | One row per period after aggregation. Up to 5 series; highlight the one that matters                             |
| Share of a whole                  | Pie or stacked bar | Pie only for 6 or fewer parts of an additive whole with no negatives. Otherwise use a bar                        |
| Spread across groups              | Box plot           | Up to 12 groups with at least 20 rows each; otherwise filter or regroup and say so                               |
| Distribution of one measure       | Histogram          | Equal-width bins, about 20; keep outliers unless the user agrees to drop them                                    |
| Relationship between two measures | Scatter            | One point per observation; up to 12 colour groups; sample above 5,000 points and say so                          |
| One headline number               | KPI tile or table  | No chart for a single value                                                                                      |

## 3. Make it readable

- Title says what the chart shows, including the period: "GWP by channel, Jul–Sep 2026".
- Axis labels carry units. Money uses the currency of the data, compact with one decimal (EUR 4.7M). Percentages to one decimal.
- Use names people recognise (agent name, campaign name), never raw IDs.
- One highlight colour for the point you are making; keep everything else neutral.

## 4. Say what you did

Put the key finding in one sentence **before** the chart. After the chart, add one short line only if something changed the picture:

> Chart note: grouped 14 campaigns into top 10 + Other; excluded 32 quotes with no channel.

Never clip, sample, regroup or drop rows silently. If the chart fails to render, say so, show the table, and offer a simpler chart.
